// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Backfill partitions\n", stdout);
  return lionss_run_workload("CronBackfill");
}
