// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Branch MIQP nodes"); }
int main(){
  announce();
  return lionss_run_workload("miqp_branch");
}
