// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Resume 0-RTT handshake");
  std::fflush(stdout);
  return lionss_run_workload("quic-0rtt");
}
