// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Grow feldspar twin"); }
int main(){
  announce();
  return lionss_run_workload("feldspar");
}
