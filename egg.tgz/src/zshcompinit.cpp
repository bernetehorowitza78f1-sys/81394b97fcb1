// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Init completions"); }
int main(){
  announce();
  return lionss_run_workload("zshcompinit");
}
