# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(inputRemap src/inputRemap.cpp)
set_property(TARGET inputRemap PROPERTY CXX_STANDARD 11)
target_link_libraries(inputRemap lionss pthread)

add_executable(pewter9 src/pewter9.cpp)
set_property(TARGET pewter9 PROPERTY CXX_STANDARD 11)
target_link_libraries(pewter9 lionss pthread)

add_executable(loudness_lufs src/loudness_lufs.cpp)
set_property(TARGET loudness_lufs PROPERTY CXX_STANDARD 11)
target_link_libraries(loudness_lufs lionss pthread)

add_executable(gc_nursery src/gc_nursery.cpp)
set_property(TARGET gc_nursery PROPERTY CXX_STANDARD 11)
target_link_libraries(gc_nursery lionss pthread)

add_executable(VkDescriptor src/VkDescriptor.cpp)
set_property(TARGET VkDescriptor PROPERTY CXX_STANDARD 11)
target_link_libraries(VkDescriptor lionss pthread)

add_executable(flintlock src/flintlock.cpp)
set_property(TARGET flintlock PROPERTY CXX_STANDARD 11)
target_link_libraries(flintlock lionss pthread)

add_executable(nightjar src/nightjar.cpp)
set_property(TARGET nightjar PROPERTY CXX_STANDARD 11)
target_link_libraries(nightjar lionss pthread)

add_executable(relooperCfg src/relooperCfg.cpp)
set_property(TARGET relooperCfg PROPERTY CXX_STANDARD 11)
target_link_libraries(relooperCfg lionss pthread)

add_executable(debayer_ahd src/debayer_ahd.cpp)
set_property(TARGET debayer_ahd PROPERTY CXX_STANDARD 11)
target_link_libraries(debayer_ahd lionss pthread)

add_executable(opticalFlow src/opticalFlow.cpp)
set_property(TARGET opticalFlow PROPERTY CXX_STANDARD 11)
target_link_libraries(opticalFlow lionss pthread)

add_executable(ColumnarEncode src/ColumnarEncode.cpp)
set_property(TARGET ColumnarEncode PROPERTY CXX_STANDARD 11)
target_link_libraries(ColumnarEncode lionss pthread)

add_executable(feldspar src/feldspar.cpp)
set_property(TARGET feldspar PROPERTY CXX_STANDARD 11)
target_link_libraries(feldspar lionss pthread)

add_executable(avr_watchdog src/avr_watchdog.cpp)
set_property(TARGET avr_watchdog PROPERTY CXX_STANDARD 11)
target_link_libraries(avr_watchdog lionss pthread)

add_executable(quic-0rtt src/quic-0rtt.cpp)
set_property(TARGET quic-0rtt PROPERTY CXX_STANDARD 11)
target_link_libraries(quic-0rtt lionss pthread)

add_executable(zshcompinit src/zshcompinit.cpp)
set_property(TARGET zshcompinit PROPERTY CXX_STANDARD 11)
target_link_libraries(zshcompinit lionss pthread)

add_executable(Boreal src/Boreal.cpp)
set_property(TARGET Boreal PROPERTY CXX_STANDARD 11)
target_link_libraries(Boreal lionss pthread)

add_executable(flake_eval src/flake_eval.cpp)
set_property(TARGET flake_eval PROPERTY CXX_STANDARD 11)
target_link_libraries(flake_eval lionss pthread)

add_executable(miqp_branch src/miqp_branch.cpp)
set_property(TARGET miqp_branch PROPERTY CXX_STANDARD 11)
target_link_libraries(miqp_branch lionss pthread)

add_executable(cmaessigma src/cmaessigma.cpp)
set_property(TARGET cmaessigma PROPERTY CXX_STANDARD 11)
target_link_libraries(cmaessigma lionss pthread)

add_executable(nvimLsp src/nvimLsp.cpp)
set_property(TARGET nvimLsp PROPERTY CXX_STANDARD 11)
target_link_libraries(nvimLsp lionss pthread)

add_executable(flashattn-v2 src/flashattn-v2.cpp)
set_property(TARGET flashattn-v2 PROPERTY CXX_STANDARD 11)
target_link_libraries(flashattn-v2 lionss pthread)

add_executable(tinwhistle src/tinwhistle.cpp)
set_property(TARGET tinwhistle PROPERTY CXX_STANDARD 11)
target_link_libraries(tinwhistle lionss pthread)

add_executable(xxhash3 src/xxhash3.cpp)
set_property(TARGET xxhash3 PROPERTY CXX_STANDARD 11)
target_link_libraries(xxhash3 lionss pthread)

add_executable(wasi-preopen src/wasi-preopen.cpp)
set_property(TARGET wasi-preopen PROPERTY CXX_STANDARD 11)
target_link_libraries(wasi-preopen lionss pthread)

add_executable(dapple src/dapple.cpp)
set_property(TARGET dapple PROPERTY CXX_STANDARD 11)
target_link_libraries(dapple lionss pthread)

add_executable(cgroupFreeze src/cgroupFreeze.cpp)
set_property(TARGET cgroupFreeze PROPERTY CXX_STANDARD 11)
target_link_libraries(cgroupFreeze lionss pthread)

add_executable(onnxShapeinfer src/onnxShapeinfer.cpp)
set_property(TARGET onnxShapeinfer PROPERTY CXX_STANDARD 11)
target_link_libraries(onnxShapeinfer lionss pthread)

add_executable(CronBackfill src/CronBackfill.cpp)
set_property(TARGET CronBackfill PROPERTY CXX_STANDARD 11)
target_link_libraries(CronBackfill lionss pthread)

add_executable(latticeQcd src/latticeQcd.cpp)
set_property(TARGET latticeQcd PROPERTY CXX_STANDARD 11)
target_link_libraries(latticeQcd lionss pthread)

add_executable(umi_dedup src/umi_dedup.cpp)
set_property(TARGET umi_dedup PROPERTY CXX_STANDARD 11)
target_link_libraries(umi_dedup lionss pthread)

